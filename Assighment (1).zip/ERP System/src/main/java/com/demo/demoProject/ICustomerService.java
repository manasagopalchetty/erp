package com.demo.demoProject;

import java.util.List;

public interface ICustomerService {
	
	/**
	 * 
	 * @return list of customer
	 */
	List<CustomerDto> getCustomers();

	/**
	 * 
	 * @implNote To add new customer
	 * @param customerDetails
	 */
	void addCustomer(CustomerDto customerDetails);
	
	/**
	 * 
	 * @implNote To update customer details
	 * @param customerId
	 * @param customerDetails
	 */
	void updateCustomerDetails(String customerId, CustomerDto customerDetails);
	
	/**
	 * 
	 * @implNote To soft delete customer entry
	 * @param customerId
	 */
	void deleteCustomer(String customerId);
	
	/**
	 * 
	 * @implNote To add customers in bulk
	 * @param customerDetails 
	 */
	List<CustomerDto> addCustomersInBulk(List<CustomerDto> customerDetails);
	
	/**
	 * 
	 * @implNote To update customer details in bulk
	 * @param customerDetails 
	 */
	List<CustomerDto> updateCustomersInBulk(List<CustomerDto> customerDetails);
	

}
