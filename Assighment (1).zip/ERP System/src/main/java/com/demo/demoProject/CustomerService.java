package com.demo.demoProject;

import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService implements ICustomerService {
	
	@Autowired
	private CustomerDao customerDao;
	
	@Override
	public List<CustomerDto> getCustomers() {
		return customerDao.getCustomers();
	}

	@Override
	public void addCustomer(CustomerDto customer) {
		// Validate requesting customer details
		if(Objects.isNull(customer)) 
			throw new IllegalArgumentException(CustomerError.CUSTOMER_CANNOT_BE_EMPTY.getError());
		
		customerDao.addCustomer(customer);
	}
	
	@Override
	public void updateCustomerDetails(String customerId, CustomerDto customerDetails) {
		// Validate requested name 
		if(StringUtils.isBlank(customerId)) 
			throw new IllegalArgumentException(CustomerError.CUSTOMER_ID_CANNOT_BE_EMPTY.getError());
		
		customerDao.updateDetails(customerId, customerDetails);
	}
	
	@Override
	public void deleteCustomer(String customerId) {
		// Validate requested name 
		if(StringUtils.isBlank(customerId)) 
			throw new IllegalArgumentException(CustomerError.CUSTOMER_ID_CANNOT_BE_EMPTY.getError());

		customerDao.deleteCustomer(customerId);
	}
	
	
	@Override
	public List<CustomerDto> addCustomersInBulk(List<CustomerDto> customers) {
		// Validating list of customers
		List<Customer> validatedCustomers = Customer.create(customers);
		
		customerDao.addCustomersInBulk(validatedCustomers);
		
		return customers;
	}
	
	@Override
	public List<CustomerDto> updateCustomersInBulk(List<CustomerDto> customers) {
		// Validating list of customers
		List<Customer> validatedCustomers = Customer.create(customers);
		
		customerDao.updateCustomersInBulk(validatedCustomers);
		
		return customers;
	}
	

}
