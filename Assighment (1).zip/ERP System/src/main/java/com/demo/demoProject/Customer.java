package com.demo.demoProject;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Customer {
	private Integer customerId;
	private String name;
	private String email;
	private String phone;
	private String address;
	private String companyName;
	private String industryType;
	private boolean customerStatus;
	private String accountManager;
	private String audit;
	

	public Customer(Integer customerId, String name, String email, String phone, String address, String companyName,
			String industryType, boolean customerStatus, String accountManager, String audit) {
		this.customerId = customerId;
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.address = address;
		this.companyName = companyName;
		this.industryType = industryType;
		this.customerStatus = customerStatus;
		this.accountManager = accountManager;
		this.audit = audit;
	}

	public static Result<Customer> create(Integer customerId, String name, String email, String phone, String address, String companyName, String industryType,
			boolean customerStatus, String accountManager, String audit) {
		
		if(!Objects.isNull(customerId))
			return Result.fail("Invalid customer Id");
			
		if(StringUtils.isBlank(name))
			return Result.fail("Invalid customer name");
		if(StringUtils.isBlank(email))
			return Result.fail("Invalid customer email");
		if(StringUtils.isBlank(phone))
			return Result.fail("Invalid customer phone");
		if(StringUtils.isBlank(address))
			return Result.fail("Invalid customer address");
		if(StringUtils.isBlank(companyName))
			return Result.fail("Invalid customer companyName");
		if(StringUtils.isBlank(industryType))
			return Result.fail("Invalid customer industryType");
		if(StringUtils.isBlank(accountManager))
			return Result.fail("Invalid customer accountManager");
		if(StringUtils.isBlank(audit))
			return Result.fail("Invalid customer audit");
		
		
		
	
		
		return Result.ok(new Customer(customerId, name, email, phone, address, companyName, industryType, customerStatus, accountManager, audit));
	}
	
	public static List<Customer> create(List<CustomerDto> customers) {
		List<Customer> validCustomers = new ArrayList<>();
		
		for(CustomerDto customer: customers) {
			Result<Customer> result = Customer.create(null, customer.getName(), customer.getEmail(), customer.getPhone(), customer.getAddress(), customer.getCompanyName(),
					customer.getCompanyName(), customer.isCustomerStatus(), customer.getAccountManager(), customer.getAudit());
			
			if(result.isFailure()) {
				customer.setErrorMessage(result.getError());
				customer.setValidationSuccess(false);
			}
			
			else
				validCustomers.add(result.getValue());
					
		}
		
		return validCustomers;
	}
	
	
	/** GETTER SETTER METHODS **/
	
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getIndustryType() {
		return industryType;
	}
	public void setIndustryType(String industryType) {
		this.industryType = industryType;
	}
	public boolean isCustomerStatus() {
		return customerStatus;
	}
	public void setCustomerStatus(boolean customerStatus) {
		this.customerStatus = customerStatus;
	}
	public String getAccountManager() {
		return accountManager;
	}
	public void setAccountManager(String accountManager) {
		this.accountManager = accountManager;
	}
	public String getAudit() {
		return audit;
	}
	public void setAudit(String audit) {
		this.audit = audit;
	}
}
