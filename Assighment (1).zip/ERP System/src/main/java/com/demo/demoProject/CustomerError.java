package com.demo.demoProject;


public enum CustomerError {

	ERROR_ADDING_CUSTOMER("Error occured while adding a customer"),
	
	ERROR_UPDATING_CUSTOMER("Error occured while updated customer details"),
	
	DELETED_CUSTOMER("Customer deleted Successfully"),
	
	ERROR_DELETING_CUSTOMER("Error occured while deleting customer"),
	
	ERROR_GETTING_CUSTOMERS("Error occured while getting customers"),
	
	CUSTOMER_ADDED("Customer added successfully"),
	
	CUSTOMER_UPDATED("Customer details updated successfully"),
	
	CUSTOMER_CANNOT_BE_EMPTY("Customer details cannot be empty"),
	
	EMPTY_CANDIDATES("Candidates are empty"),
	
	CUSTOMER_ID_CANNOT_BE_EMPTY("Customer id cannot be empty")
	;
	
	

	

	private final String error;
	
	CustomerError(String error) {
		this.error = error;
	}

	public String getError() {
		return error;
	}
}
