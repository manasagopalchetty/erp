package com.demo.demoProject;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerDao {
	
private final JdbcTemplate jdbcTemplate;

	@Autowired
	public CustomerDao(JdbcTemplate jdbcTemplate) {
	    this.jdbcTemplate = jdbcTemplate;
	}
	
	public List<CustomerDto> getCustomers() {
		String selectSql = "SELECT * FROM customer WHERE customer_status = 1 ";
        try {
            return this.jdbcTemplate.query(selectSql,
                    new BeanPropertyRowMapper<>(CustomerDto.class));
        } catch (EmptyResultDataAccessException e){
            return Collections.emptyList();
        }
	}

	
	public void addCustomer(CustomerDto customer) {
		String insertSql = "INSERT INTO CUSTOMER (name, email, phone, address, company_name, insdustry_type, account_manager, audit) VALUES " + 
							"(?, ?, ?, ?, ?, ?, ?, ?) ";
		
		this.jdbcTemplate.update(insertSql,
                customer.getName(), customer.getEmail(), customer.getPhone(), customer.getAddress(), customer.getCompanyName(),
                customer.getIndustryType(), customer.isCustomerStatus(), customer.getAccountManager(), customer.getAudit());
	}
	
	public void updateDetails(String customerId, CustomerDto customer) {
		String updateSql = "UPDATE customer SET name = ?, email = ?, phone = ?, address = ?, company_name = ?, " + 
				" industry_type = ?, account_manager = ?, audit = ? " +
				" WHERE customer_id = ? " ;

		this.jdbcTemplate.update(updateSql,
		    customer.getName(), customer.getEmail(), customer.getPhone(), customer.getAddress(), customer.getCompanyName(),
		    customer.getIndustryType(), customer.isCustomerStatus(), customer.getAccountManager(), customer.getAudit(), customerId);
		
	}
	
	public void deleteCustomer(String customerId) {
		String updateSql = "UPDATE customer SET customer_status = 0 " +
				" WHERE customer_id = ? " ;

		this.jdbcTemplate.update(updateSql, customerId);
	}
	
	public void addCustomersInBulk(List<Customer> customers) {
		String insertSql = "INSERT INTO CUSTOMER (name, email, phone, address, company_name, insdustry_type, account_manager, audit) VALUES " + 
				"(?, ?, ?, ?, ?, ?, ?, ?) ";
		
		this.jdbcTemplate.batchUpdate(insertSql,
                new BatchPreparedStatementSetter() {

                    public void setValues(PreparedStatement ps, int i)
                            throws SQLException {

                        Customer customer = customers.get(i);

                        ps.setString(1, customer.getName());
                        ps.setString(2, customer.getEmail());
                        ps.setString(3, customer.getPhone());
                        ps.setString(4, customer.getAddress());
                        ps.setString(5, customer.getCompanyName());
                        ps.setString(6, customer.getIndustryType());
                        ps.setString(7, customer.getAccountManager());
                        ps.setString(8, customer.getAudit());
                        
                    }

                    public int getBatchSize() {
                        return customers.size();
                    }
                });
	}
	
	
	public void updateCustomersInBulk(List<Customer> customers) {
		String updateSql = "INSERT INTO CUSTOMER (name, email, phone, address, company_name, insdustry_type, account_manager, audit) VALUES " + 
				"(?, ?, ?, ?, ?, ?, ?, ?) WHERE customer_id = ? ";
		
		this.jdbcTemplate.batchUpdate(updateSql,
                new BatchPreparedStatementSetter() {

                    public void setValues(PreparedStatement ps, int i)
                            throws SQLException {

                        Customer customer = customers.get(i);

                        ps.setString(1, customer.getName());
                        ps.setString(2, customer.getEmail());
                        ps.setString(3, customer.getPhone());
                        ps.setString(4, customer.getAddress());
                        ps.setString(5, customer.getCompanyName());
                        ps.setString(6, customer.getIndustryType());
                        ps.setString(7, customer.getAccountManager());
                        ps.setString(8, customer.getAudit());
                        ps.setInt(9, customer.getCustomerId());
                        
                    }

                    public int getBatchSize() {
                        return customers.size();
                    }
                });
	}
	
	
}
