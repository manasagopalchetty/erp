package com.demo.demoProject;

import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import ch.qos.logback.classic.Logger;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.websocket.server.PathParam;

@RestController
@RequestMapping("/")
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	
	private static final Logger logger = (Logger) LoggerFactory.getLogger(CustomerController.class);

	
	/**
	 * @apiNote To return list of customers
	 */
	@GetMapping(path = "/getCustomers")
	public ResponseEntity<?> getCustomers(HttpServletRequest request) {
		try {
			return ResponseEntity.status(HttpStatus.OK).body(customerService.getCustomers());
		}
		catch(IllegalArgumentException e ) {
			logger.error(CustomerError.ERROR_GETTING_CUSTOMERS.getError(), e.getMessage());
			return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
		catch(Exception e) {
			logger.error(CustomerError.ERROR_GETTING_CUSTOMERS.getError(), e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}
	
	/**
	 * @apiNote To add a new customer
	 * @param customerDetails requesting customer details
	 */
	@PostMapping(path = "/addCustomer")
	public ResponseEntity<?> addCustomer(HttpServletRequest request,
											@RequestBody CustomerDto customerDetails) {
		try {
			customerService.addCustomer(customerDetails);
			return ResponseEntity.status(HttpStatus.CREATED).body(CustomerError.CUSTOMER_ADDED.getError());
		}
		catch(IllegalArgumentException e ) {
			logger.error(CustomerError.ERROR_ADDING_CUSTOMER.getError(), e.getMessage());
			return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
		catch(Exception e) {
			logger.error(CustomerError.ERROR_ADDING_CUSTOMER.getError(), e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}
	
	/**
	 * @apiNote To update customer details
	 * @param customerId 
	 * @param customerDetails
	 */
	@PutMapping(path = "/updateCustomer/{customerId}")
	public ResponseEntity<?> updateCustomerDetails(HttpServletRequest request,
									@PathParam("customerId") String customerId, 
									@RequestBody CustomerDto customerDetails) {
								
		try {
			customerService.updateCustomerDetails(customerId, customerDetails);
			return ResponseEntity.status(HttpStatus.OK).body(CustomerError.CUSTOMER_UPDATED.getError());
		}
		catch(IllegalArgumentException e ) {
			logger.error(CustomerError.ERROR_UPDATING_CUSTOMER.getError(), e.getMessage());
			return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
		catch(Exception e) {
			logger.error(CustomerError.ERROR_UPDATING_CUSTOMER.getError(), e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}
	
	/**
	 * @apiNote To soft delete customer entry
	 * @param customerId
	 */
	@PutMapping(path = "/delete/{customerId}")
	public ResponseEntity<?> countVote(HttpServletRequest request,
											@PathParam("customerId") String customerId) {
		try {
			customerService.deleteCustomer(customerId);
			return ResponseEntity.status(HttpStatus.OK).body(CustomerError.DELETED_CUSTOMER.getError());
		}
		catch(IllegalArgumentException e ) {
			logger.error(CustomerError.ERROR_DELETING_CUSTOMER.getError(), e.getMessage());
			return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
		catch(Exception e) {
			logger.error(CustomerError.ERROR_DELETING_CUSTOMER.getError(), e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}
	
	/**
	 * @apiNote To add customers in bulk
	 * @param customerDetails list of customer details
	 */
	@PostMapping(path = "/addCustomersBulk")
	public ResponseEntity<?> addCustomersInBulk(HttpServletRequest request,
											@RequestBody List<CustomerDto> customers) {
		try {
			customerService.addCustomersInBulk(customers);
			return ResponseEntity.status(HttpStatus.CREATED).body(customerService.addCustomersInBulk(customers));
		}
		catch(IllegalArgumentException e ) {
			logger.error(CustomerError.ERROR_ADDING_CUSTOMER.getError(), e.getMessage());
			return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
		catch(Exception e) {
			logger.error(CustomerError.ERROR_ADDING_CUSTOMER.getError(), e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}
	
	
	/**
	 * @apiNote To update customers in bulk
	 * @param customerDetails list of customer details
	 */
	@PutMapping(path = "/updateCustomersBulk")
	public ResponseEntity<?> updateCustomersInBulk(HttpServletRequest request,
											@RequestBody List<CustomerDto> customers) {
		try {
			customerService.updateCustomersInBulk(customers);
			return ResponseEntity.status(HttpStatus.OK).body(customerService.updateCustomersInBulk(customers));
		}
		catch(IllegalArgumentException e ) {
			logger.error(CustomerError.ERROR_ADDING_CUSTOMER.getError(), e.getMessage());
			return  ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
		catch(Exception e) {
			logger.error(CustomerError.ERROR_ADDING_CUSTOMER.getError(), e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
	}

}
