package com.demo.demoProject;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest(webEnvironment = RANDOM_PORT)
class ApplicationTest {
	
	private static final Integer VALID_CUSTOMER_ID = 333;
    private static final String VALID_CUSTOMER_NAME = "Manasa";
    private static final String VALID_CUSTOMER_EMAIL = "manasa.k@gmail.com";
    private static final String VALID_CUSTOMER_PHONE = "9839288489";
    private static final String VALID_CUSTOMER_ADDRESS = "Bangalore";
    private static final String VALID_COMPANY_NAME = "Alberno";
    private static final String VALID_INDUSTRY_TYPE = "Education Technology";
    private static final String VALID_ACCOUNT_MANAGER = "Tapaswee";
    private static final String VALID_AUDIT = "Account";
    
    private static final Integer INVALID_CUSTOMER_ID = -5;
    private static final String INVALID_CUSTOMER_NAME = "";
    private static final String INVALID_CUSTOMER_EMAIL = "";
    private static final String INVALID_CUSTOMER_PHONE ="";
    private static final String INVALID_CUSTOMER_ADDRESS = "";
    private static final String INVALID_COMPANY_NAME = "";
    private static final String INVALID_INDUSTRY_TYPE = "";
    private static final String INVALID_ACCOUNT_MANAGER = "";
    private static final String INVALID_AUDIT = "";

    
    @Test
    public void testValidCustomer() {
        Result<Customer> result = Customer.create(VALID_CUSTOMER_ID, VALID_CUSTOMER_NAME, VALID_CUSTOMER_EMAIL,
        		VALID_CUSTOMER_PHONE, VALID_CUSTOMER_ADDRESS, VALID_COMPANY_NAME, VALID_INDUSTRY_TYPE, true, VALID_ACCOUNT_MANAGER, VALID_AUDIT);
        
        assertFalse(result.isFailure());
        assertEquals(VALID_CUSTOMER_ID, result.getValue().getCustomerId());
        assertEquals(VALID_CUSTOMER_NAME, result.getValue().getName());
        assertEquals(VALID_CUSTOMER_EMAIL, result.getValue().getEmail());
        assertEquals(VALID_CUSTOMER_PHONE, result.getValue().getPhone());
        assertEquals(VALID_CUSTOMER_ADDRESS, result.getValue().getAddress());
        assertEquals(VALID_COMPANY_NAME, result.getValue().getCompanyName());
        assertEquals(VALID_INDUSTRY_TYPE, result.getValue().getIndustryType());
        assertEquals(true, result.getValue().isCustomerStatus());
        assertEquals(VALID_ACCOUNT_MANAGER, result.getValue().getAccountManager());
        assertEquals(VALID_AUDIT, result.getValue().getAudit());
        	
    }
    
    @Test
    public void testInvalidCustomerId() {
    	Result<Customer> result = Customer.create(INVALID_CUSTOMER_ID, VALID_CUSTOMER_NAME, VALID_CUSTOMER_EMAIL,
        		VALID_CUSTOMER_PHONE, VALID_CUSTOMER_ADDRESS, VALID_COMPANY_NAME, VALID_INDUSTRY_TYPE, true, VALID_ACCOUNT_MANAGER, VALID_AUDIT);
    	
    	assertTrue(result.isFailure());
    	assertEquals("Invalid customer id", result.getError());
    }

    @Test
    public void testInvalidName() {
    	Result<Customer> result = Customer.create(VALID_CUSTOMER_ID, INVALID_CUSTOMER_NAME, VALID_CUSTOMER_EMAIL,
        		VALID_CUSTOMER_PHONE, VALID_CUSTOMER_ADDRESS, VALID_COMPANY_NAME, VALID_INDUSTRY_TYPE,true, VALID_ACCOUNT_MANAGER, VALID_AUDIT);
    	
    	assertTrue(result.isFailure());
    	assertEquals("Invalid customer name", result.getError());
    }
    @Test
    public void testInvalidEmail() {
    	Result<Customer> result = Customer.create(VALID_CUSTOMER_ID, VALID_CUSTOMER_NAME, INVALID_CUSTOMER_EMAIL,
        		VALID_CUSTOMER_PHONE, VALID_CUSTOMER_ADDRESS, VALID_COMPANY_NAME, VALID_INDUSTRY_TYPE, true, VALID_ACCOUNT_MANAGER, VALID_AUDIT);
    	
    	assertTrue(result.isFailure());
    	assertEquals("Invalid customer Email", result.getError());
    }
    @Test
    public void INVALID_CUSTOMER_PHONE () {
    	Result<Customer> result = Customer.create(VALID_CUSTOMER_ID, VALID_CUSTOMER_NAME, VALID_CUSTOMER_EMAIL,
        		INVALID_CUSTOMER_PHONE, VALID_CUSTOMER_ADDRESS, INVALID_COMPANY_NAME, VALID_INDUSTRY_TYPE, true, VALID_ACCOUNT_MANAGER, VALID_AUDIT);
    	
    	assertTrue(result.isFailure());
    	assertEquals("Invalid customer phone", result.getError());
    }
    @Test
    public void testInvalidPhone() {
    	Result<Customer> result = Customer.create(VALID_CUSTOMER_ID, INVALID_CUSTOMER_NAME, VALID_CUSTOMER_EMAIL,
        		INVALID_CUSTOMER_PHONE, VALID_CUSTOMER_ADDRESS, VALID_COMPANY_NAME, VALID_INDUSTRY_TYPE, true, VALID_ACCOUNT_MANAGER, VALID_AUDIT);
    	
    	assertTrue(result.isFailure());
    	assertEquals("Invalid customer phone", result.getError());
    }
    @Test
    public void testInvalidAddress() {
    	Result<Customer> result = Customer.create(VALID_CUSTOMER_ID, VALID_CUSTOMER_NAME, VALID_CUSTOMER_EMAIL,
        		VALID_CUSTOMER_PHONE, INVALID_CUSTOMER_ADDRESS, VALID_COMPANY_NAME, VALID_INDUSTRY_TYPE, true, VALID_ACCOUNT_MANAGER, VALID_AUDIT);
    	
    	assertTrue(result.isFailure());
    	assertEquals("Invalid customer address", result.getError());
    }
    @Test
    public void testInvalidcompanyName() {
    	Result<Customer> result = Customer.create(VALID_CUSTOMER_ID, VALID_CUSTOMER_NAME, VALID_CUSTOMER_EMAIL,
        		VALID_CUSTOMER_PHONE, VALID_CUSTOMER_ADDRESS, INVALID_COMPANY_NAME, VALID_INDUSTRY_TYPE, true, VALID_ACCOUNT_MANAGER, VALID_AUDIT);
    	
    	assertTrue(result.isFailure());
    	assertEquals("Invalid customer companyname", result.getError());
    }
    @Test
    public void INVALID_INDUSTRY_TYPE() {
    	Result<Customer> result = Customer.create(VALID_CUSTOMER_ID, VALID_CUSTOMER_NAME, VALID_CUSTOMER_EMAIL,
        		VALID_CUSTOMER_PHONE, INVALID_CUSTOMER_ADDRESS, VALID_COMPANY_NAME, INVALID_INDUSTRY_TYPE, true, VALID_ACCOUNT_MANAGER, VALID_AUDIT);
    	
    	assertTrue(result.isFailure());
    	assertEquals("Invalid Industry type", result.getError());
    }
    @Test
    public void testInvalidaccountManager() {
    	Result<Customer> result = Customer.create(VALID_CUSTOMER_ID, VALID_CUSTOMER_NAME, VALID_CUSTOMER_EMAIL,
        		VALID_CUSTOMER_PHONE, VALID_CUSTOMER_ADDRESS, VALID_COMPANY_NAME, VALID_INDUSTRY_TYPE, true, INVALID_ACCOUNT_MANAGER, VALID_AUDIT);
    	
    	assertTrue(result.isFailure());
    	assertEquals("Invalid customer account manager", result.getError());
    }
    
    @Test
    public void testInvalidAudit() {
    	Result<Customer> result = Customer.create(VALID_CUSTOMER_ID, VALID_CUSTOMER_NAME, VALID_CUSTOMER_EMAIL,
        		VALID_CUSTOMER_PHONE, VALID_CUSTOMER_ADDRESS, VALID_COMPANY_NAME, VALID_INDUSTRY_TYPE, true, VALID_ACCOUNT_MANAGER, INVALID_AUDIT);
    	
    	assertTrue(result.isFailure());
    	assertEquals("Invalid customer audit", result.getError());
    }
    
   
}
